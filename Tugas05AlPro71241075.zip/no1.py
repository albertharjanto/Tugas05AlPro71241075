def cek_angka(a, b, c):
    if a != b and b != c and a != c:
        if a + b == c or a + c == b or b + c == a:
            return True
        else:
            return False
    else:
        return False
    
print(cek_angka(1, 2, 3)) 
print(cek_angka(3, 1, 2))
print(cek_angka(2, 2, 2)) 
print(cek_angka(4, 1, 2)) 
print(cek_angka(2, 2, 4))
print(cek_angka(4, 5, 4))