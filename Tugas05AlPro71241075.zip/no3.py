celcius_farenheit = lambda c: (9/5) * c + 32
celcius_reamur = lambda c: 0.8 * c

print("F =", int(celcius_farenheit(100)))
print("R =", int(celcius_reamur(80)))
print("F =", int(celcius_farenheit(0)))